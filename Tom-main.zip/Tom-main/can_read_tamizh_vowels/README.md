# MNIST-Tom-Triplet Network
TOM ( A Trained Model ) detects the TAMIZH - Handwritten Vowels
<h1>SCREENSHOT 1</h1>
<img src="https://github.com/arihara-sudhan/Tom-TAMIZH-Vowels/blob/main/ScShots/Screenshot%20from%202023-07-10%2012-08-42.png?raw=true" alt="">
<br>
<h3>First, train the model and save it in model folder. Then, execute main.py with all the dependencies resolved.</h3>
<h1>DATASET IS AVAILABLE <a href="https://www.kaggle.com/datasets/aravindariharasudhan/tamizh-vowels">HERE</a></h1>

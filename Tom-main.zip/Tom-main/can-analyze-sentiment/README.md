<h2>CLICK 👇</h2>
<a href="https://www.linkedin.com/embed/feed/update/urn:li:ugcPost:7074554168719376384?compact=1" allowfullscreen="" title="Embedded post" width="710" height="399" frameborder="0">MEET MR.SENTIMENT TOM</a>
